ALTER TABLE `repdose_old`.`substance`
 DROP FOREIGN KEY `substance_ibfk_1`;

ALTER TABLE `repdose_old`.`substance` ADD CONSTRAINT `substance_ibfk_1` FOREIGN KEY `substance_ibfk_1` (`stype_id`)
    REFERENCES `stype` (`stype_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE;

ALTER TABLE `repdose_old`.`structure`
 DROP FOREIGN KEY `structure_ibfk_1`;

ALTER TABLE `repdose_old`.`structure` ADD CONSTRAINT `structure_ibfk_1` FOREIGN KEY `structure_ibfk_1` (`idsubstance`)
    REFERENCES `substance` (`idsubstance`)
    ON DELETE CASCADE
    ON UPDATE CASCADE;


delete substance from substance , structure
where substance.idsubstance = structure.idsubstance;

delete from src_dataset;