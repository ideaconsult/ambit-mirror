ALTER TABLE substance
 DROP FOREIGN KEY `substance_ibfk_1`;

ALTER TABLE `substance` ADD CONSTRAINT `substance_ibfk_1` FOREIGN KEY `substance_ibfk_1` (`stype_id`)
    REFERENCES `stype` (`stype_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE;

ALTER TABLE `structure`
 DROP FOREIGN KEY `structure_ibfk_1`;

ALTER TABLE `structure` ADD CONSTRAINT `structure_ibfk_1` FOREIGN KEY `structure_ibfk_1` (`idsubstance`)
    REFERENCES `substance` (`idsubstance`)
    ON DELETE CASCADE
    ON UPDATE CASCADE;


delete from cas;
delete from alias;

delete substance from substance , structure
where substance.idsubstance = structure.idsubstance;

delete from src_dataset;

delete from ref_authors;
delete from author;
delete from journal;
delete from literature;

delete from ambituser;

delete from stype;
delete from version;

delete from dsname;
delete from fpae;